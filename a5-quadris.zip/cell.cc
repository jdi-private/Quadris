#include "cell.h"

Info Cell::getInfo() {
	return info;
}

void Cell::setinfo(Info inf) {
	info = inf;
}
