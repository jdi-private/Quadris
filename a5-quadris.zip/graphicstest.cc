//#include "window.h"
//#include <iostream>
//using namespace std;
//int main() {
//  Xwindow xw{1000,1600};
//  xw.fillRectangle(195, 75, 5,1080 , Xwindow::Black);
//  xw.fillRectangle(195, 75, 665, 5, Xwindow::Black);
//  xw.fillRectangle(195, 1155, 665, 5, Xwindow::Black);
//  xw.fillRectangle(860, 75, 5, 1085, Xwindow::Black);
//  // Title:
//  xw.drawBigString(400, 73, "QUADRIS");
//  xw.drawString(10, 75, "Created by:");
//  xw.drawString(10, 100, "Owen &");
//  xw.drawString(10, 125, "Aaron &");
//  xw.drawString(10, 150, "Jimmy");
//  // Credits: :-)
//  int s = 1;
//  for (int i = 0; i < 11; i++) {
//      xw.fillRectangle(200 + (60 * i), 80, 60, 60, s);
//      s++;
//      if (s == 9) { s = 1;}
//  }
//  for (int i = 1; i < 18; i++) {
//      xw.fillRectangle(200, 80 + (60 * i), 60, 60, s);
//      s++;
//      if (s == 9) { s = 1;}
//  }
//  int x;
//  cin >> x;
//}

