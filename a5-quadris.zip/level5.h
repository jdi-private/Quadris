#ifndef _LEVEL5_H
#define _LEVEL5_H
#include "level.h"

class Level5: public Level {
public:
	Block *genetateBlock()
}


#endif
